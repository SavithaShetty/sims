import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { FlipModule } from 'ngx-flip';
import { ChartsModule } from 'ng2-charts';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { jqxChartModule } from 'jqwidgets-ng/jqxchart';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import 'hammerjs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
// import { HttpModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { GalleryModule, GalleryConfig } from 'ng-gallery';
// import { BusyModule, BusyConfig } from 'angular2-busy';
// import {MaterialModule} from'./material.module';
// import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
// import { GaugesModule } from '@progress/kendo-angular-gauges';
// import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import { DatePipe } from '@angular/common';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Pages/header/header.component';
import { DashboardComponent } from './NewPages/dashboard/dashboard.component';
import { Dash2Component } from './NewPages/dash2/dash2.component';
import {BarchartComponent} from './NewPages/barchart/barchart.component';
import { SidemenuComponent } from './Pages/sidemenu/sidemenu.component';

// export const galleryConfig: GalleryConfig = {
// }


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DashboardComponent,
    Dash2Component,
    BarchartComponent,
    SidemenuComponent,

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChartsModule,
    FlipModule,
    MDBBootstrapModule.forRoot(),
    CommonModule ,
    BrowserAnimationsModule,
    jqxChartModule,
    ScrollingModule,
    ReactiveFormsModule,
    FormsModule,
    // HttpModule,
    // MaterialModule,
    NoopAnimationsModule,
    // NgbModule.forRoot(),
    // BusyModule.forRoot(<BusyConfig>{
    // message: '',
    // backdrop: true,
    // template: '<div><img width="50px" src="../../angular/dist/assets/Images/loading.gif"></div>',
    // delay: 0,
    // minDuration: 0,
    // wrapperClass: 'loadingPanelWrapper'
    // }),
    // GalleryModule.forRoot(galleryConfig),
    // AgGridModule.withComponents(),
    // HttpClientModule,
    // GaugesModule,
    // MatDatepickerModule,
    // MatNativeDateModule
  ],
  providers: [ DatePipe],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule { }
